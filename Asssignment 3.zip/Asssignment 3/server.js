/********************************************************************************
 *  WEB322 – Assignment 02
 *
 *  I declare that this assignment is my own work in accordance with Seneca's
 *  Academic Integrity Policy:
 *
 *  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
 *
 *  Name: _______Yongky Chandra Student ID: ______128665221 Date: ___19 June 2024
 ********************************************************************************/

const express = require('express');
const legoData = require("./modules/legoSets");
const path = require('path');
const app = express();
const HTTP_PORT = process.env.HTTP_PORT || 8080;

app.use(express.static('public'));

legoData.initialize()
  .then(() => {
    app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, 'views/home.html'));
    });

    app.get('/about', (req, res) => {
      res.sendFile(path.join(__dirname, 'views/about.html'));
    });

    app.get('/lego/sets', (req, res) => {
      const theme = req.query.theme;
      if (theme) {
        legoData.getSetsByTheme(theme)
          .then(sets => {
            if (sets) {
              res.json(sets);
            } else {
              res.status(404).sendFile(path.join(__dirname, 'views/404.html'));
            }
          })
          .catch(err => res.status(404).json({ error: err.message }));
      } else {
        legoData.getAllSets()
          .then(sets => res.json(sets))
          .catch(err => res.status(404).json({ error: err.message }));
      }
    });

    app.get('/lego/sets/:id', (req, res) => {
      const setId = req.params.id;
      legoData.getSetByNum(setId)
        .then(set => {
          if (sets) {
            res.json(set);
          } else {
            res.status(404).sendFile(path.join(__dirname, 'views/404.html'));
          }
        })
        .catch(err => res.status(404).json({ error: err.message }));
    });

    app.use((req, res) => {
      res.status(404).sendFile(path.join(__dirname, 'views/404.html'));
    });

    app.listen(HTTP_PORT, () => {
      console.log(`Server is running on port ${HTTP_PORT}`);
    });
  })
  .catch(err => {
    console.error('Failed to initialize lego data:', err);
  });